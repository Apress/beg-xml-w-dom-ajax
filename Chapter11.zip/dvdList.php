<?php
$xsl = new DomDocument(); 
$xsl->load("dvdDetails1.xsl"); 
$inputdom = new DomDocument(); 
$inputdom->load("dvd.xml"); 


$proc = new XsltProcessor(); 
$xsl = $proc->importStylesheet($xsl); 

$newdom = $proc->transformToDoc($inputdom); 

print $newdom->saveXML();
?>