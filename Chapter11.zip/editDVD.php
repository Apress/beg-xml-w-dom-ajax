<?php
  $id = $_GET['id'];

  $dom = new DomDocument();
  $dom->load("dvd.xml");
  
  $path = "/library/DVD[@id=" . $id . "]";
  $xPath = new domxpath($dom);
  $selectedNode = $xPath->query($path)->item(0);
  
  foreach ($selectedNode->childNodes as $child) { 
    if ($child->nodeName == "title") { 
      $title = $child->textContent;
	}
	elseif ($child->nodeName == "format") { 
      $format = $child->textContent;
	}
	elseif ($child->nodeName == "genre") { 
      $genre = $child->textContent;
	}
  }
 
  ?>
<html>
<head>
    <link href="styles.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <h1>Edit DVD Details</h1>
    <form id="frmEditDVD" method="POST" action="editDVDAction.php">
	<input type="hidden" name="txtID" value="<?php echo $id; ?>"/>
        <table>
            <tr>
                <td class="emphasis">Title:</td>
                <td><input name="txtTitle" type="text" size="30" maxlength="50" value="<?php echo $title; ?>"/></td>
            </tr>
            <tr>
                <td class="emphasis">Format:</td>
                <td><input name="txtFormat" type="text" size="30" maxlength="50" value="<?php echo $format; ?>"/></td>
            </tr>
            <tr>
                <td class="emphasis">Genre:</td>
                <td><input name="txtGenre" type="text" size="30" maxlength="50" value="<?php echo $genre; ?>"/></td>
            </tr>
            <tr>
                <td class="emphasis" colspan="2">
                    <input type="submit" id="btnAdd" value="Update DVD"/>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
