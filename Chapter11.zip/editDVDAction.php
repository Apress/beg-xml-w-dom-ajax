<?php
  $id = $_POST['txtID'];
  $title = $_POST['txtTitle'];
  $format = $_POST['txtFormat'];
  $genre = $_POST['txtGenre'];
  
  
  $dom = new DomDocument();
  $dom->preserveWhiteSpace = false;
  $dom->formatOutput = true;
  $dom->load("dvd.xml"); 
  
  $path = "/library/DVD[@id=" . $id . "]";
  $xPath = new domxpath($dom);
  $selectedNode = $xPath->query($path)->item(0);

  foreach ($selectedNode->childNodes as $child) {
	if ($child->nodeName == "title") { 
	  $child ->firstChild->nodeValue = $title;
	}
	elseif ($child->nodeName == "format") { 
      $child->firstChild->nodeValue = $format;
	}
	elseif ($child->nodeName == "genre") { 
      $child->firstChild->nodeValue = $genre;
	}
  }

$dom->save("dvd.xml");
?>
<html>
  <head>
    <link href="styles.css" type="text/css" rel="stylesheet" />
  </head>
    <body>
		<div id="divMessage">You have successfully updated the XML document</div>
	</body>
</html>
